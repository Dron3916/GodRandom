# my_library/__init__.py
from .main import *

